# Complexo Favela Panel — protótipo Android

Este é um projeto Android Studio com uma interface de painel escura em preto/vermelho, controles demonstrativos, slider de FOV, minimizar, fechar e arrastar o painel.

**Importante:** o aplicativo não se conecta ao Complexo Favela, não lê nem modifica memória do jogo, não implementa ESP/aimbot funcional e não contorna anti-cheat ou banimentos. Os controles são apenas demonstração visual.

## Como gerar o APK
1. Extraia o ZIP.
2. Abra a pasta `ComplexoFavelaPanel` no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Selecione **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK de debug será gerado em `app/build/outputs/apk/debug/app-debug.apk`.

Requisitos: Android Studio recente, JDK 17 e Android SDK Platform 35.
