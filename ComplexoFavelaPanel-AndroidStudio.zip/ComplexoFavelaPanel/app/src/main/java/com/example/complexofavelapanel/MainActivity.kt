package com.example.complexofavelapanel

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(15, 15, 18)
    private val panel = Color.rgb(27, 27, 33)
    private val red = Color.rgb(255, 59, 48)
    private lateinit var content: LinearLayout
    private lateinit var body: LinearLayout
    private var minimized = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(bg)
            setPadding(dp(18), dp(18), dp(18), dp(18))
        }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(panel)
            setPadding(dp(16), dp(14), dp(16), dp(16))
            elevation = dp(8).toFloat()
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "COMPLEXO FAVELA  •  PANEL"
            textSize = 16f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        header.addView(title, LinearLayout.LayoutParams(0, dp(42), 1f))
        val min = button("—") { toggleMinimize() }
        val close = button("×") { finish() }
        header.addView(min)
        header.addView(close)
        content.addView(header)

        val line = View(this).apply { setBackgroundColor(red) }
        content.addView(line, LinearLayout.LayoutParams(-1, dp(2)))

        body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(12), 0, 0)
        }
        body.addView(section("RECURSOS — MODO DEMONSTRAÇÃO"))
        body.addView(toggleRow("ESP — nome/distância (visual de demonstração)"))
        body.addView(toggleRow("FOV — indicador visual"))
        body.addView(toggleRow("Assistência de mira — indisponível neste protótipo", false))
        body.addView(label("Tamanho do FOV"))
        val seek = SeekBar(this).apply {
            max = 100
            progress = 35
            progressTintList = android.content.res.ColorStateList.valueOf(red)
            thumbTintList = android.content.res.ColorStateList.valueOf(red)
        }
        body.addView(seek)
        val value = label("FOV: 35")
        body.addView(value)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                value.text = "FOV: $p"
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        body.addView(label("Este aplicativo é apenas uma interface demonstrativa. Não se conecta ao jogo, não altera sua memória e não oferece bypass de anti-cheat ou banimento."))
        content.addView(body)
        root.addView(content, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)

        // Permite arrastar o painel dentro da tela.
        header.setOnTouchListener(object : View.OnTouchListener {
            var downX = 0f; var downY = 0f; var startX = 0f; var startY = 0f
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = e.rawX; downY = e.rawY
                        startX = content.translationX; startY = content.translationY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        content.translationX = startX + e.rawX - downX
                        content.translationY = startY + e.rawY - downY
                        return true
                    }
                }
                return true
            }
        })
    }

    private fun toggleMinimize() {
        minimized = !minimized
        body.visibility = if (minimized) View.GONE else View.VISIBLE
    }

    private fun toggleRow(text: String, enabled: Boolean = true): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(7), 0, dp(7))
        }
        val tv = TextView(this).apply {
            this.text = text
            textSize = 13f
            setTextColor(if (enabled) Color.WHITE else Color.LTGRAY)
        }
        row.addView(tv, LinearLayout.LayoutParams(0, -2, 1f))
        val sw = Switch(this).apply {
            isChecked = false
            isEnabled = enabled
            buttonTint(red)
        }
        row.addView(sw)
        return row
    }

    private fun button(text: String, action: () -> Unit): TextView =
        TextView(this).apply {
            this.text = text
            textSize = 20f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setPadding(dp(10), 0, dp(10), 0)
            setOnClickListener { action() }
        }

    private fun section(text: String) = TextView(this).apply {
        this.text = text
        textSize = 11f
        setTextColor(red)
        typeface = Typeface.DEFAULT_BOLD
        setPadding(0, dp(8), 0, dp(8))
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = text
        textSize = 12f
        setTextColor(Color.LTGRAY)
        setPadding(0, dp(8), 0, dp(4))
    }

    private fun Switch.buttonTint(color: Int) {
        thumbTintList = android.content.res.ColorStateList.valueOf(color)
        trackTintList = android.content.res.ColorStateList.valueOf(color)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
